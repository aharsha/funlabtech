var expModule = require("express");
var expObject = expModule();

var mongoModule = require("mongodb");
var mongoDbObj=mongoModule.MongoClient;

var dbUrl = "mongodb://localhost:27017/eshop";
var dbObject;
mongoDbObj.connect(dbUrl,function(err,dbRef)
{
if(err) throw err;
console.log("database connected");
//create database object to use in api's
dbObject = dbRef.db("eshop");
console.log("database object is created for doing CRUD transactions");
});

var productList;
//create showpro api 
expObject.get("/showpro", function(req,res)
{
 dbObject.collection("product").find({}).toArray(function(err,result)
    {
    if(err) throw err;
   productList = result;
   console.log(productList);
   res.send(productList);
    })
});

var parser = require("body-parser");
expObject.use(parser.json());

expObject.post("/addpro",function(req,res)
{
    //test request data
    console.log("product-id = "+req.body.productid);
    //prepare json object with request data
var pro = {
    "product-id": req.body.productid,
    "product-name": req.body.productname,
    "product-price" : req.body.productprice
 }
   //send above pro json object to database
  dbObject.collection("product").insertOne(pro,function(err,result)
  {
      if(err) throw err;
      console.log(" product inserted to database");
  })
res.send("product added successfully");
});

//here deletepro is api and pid is requestparameter
expObject.get("/deletepro/:pid",function(req,res)
{
console.log(req.params.pid);
var pro = {"product-id": req.params.pid };
console.log("deleting "+pro);
dbObject.collection("product").deleteOne(pro, function(err,result)
{
    if(err) throw err;
    console.log("product deleted");
    res.send("product deleted successfully"+pro);
})
});


expObject.listen(4141,function()
{
    console.log("server started on 4141 port");
})