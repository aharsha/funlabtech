var fileop = require("fs");

fileop.readFile('abcd.txt' ,function(e,data)
{
    if(e)
    {
        return console.error(e);
    } 
    for(i=0; i<5; i++)
    {
console.log(i);
    }
console.log("file data is "+data.toString());
});

//var d = fileop.readFileSync('abc.txt');
//console.log("file data is "+d.toString());