module.exports = function(firstname,lastname)
{
    this.fullname = function()
    {
        return firstname + ' ' + lastname;
    }
}