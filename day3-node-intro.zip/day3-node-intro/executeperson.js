//importing local module
var p= require('./person.js');

//creating object through module
var person = new p('harsha','vardhan');

//call function of that module
console.log(person.fullname());
