var fileop = require('fs');

fileop.appendFile('bbc.txt', 'hello', function(err)
{
if(err)
{
    return console.error(err);
}
else{
    console.log("writing data to bbc.txt is done");
}
})